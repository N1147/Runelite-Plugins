package net.runelite.client.plugins.NGuardians;

public enum NGuardiansState
{
	TIMEOUT,
	ANIMATING,
	IDLE,
	UNHANDLED_STATE;
}
