package net.runelite.client.plugins.arooftops;

public enum ARooftopsState {
    ANIMATING,
    CAST_CAMELOT_TELEPORT,
    FIND_OBSTACLE,
    HIGH_ALCH,
    MARK_OF_GRACE,
    MOVING,
    PRIFF_PORTAL,
    RESTOCK_ITEMS,
    TIMEOUT,
    EAT_SUMMER_PIE,
    OUT_OF_SUMMER_PIES;
}
