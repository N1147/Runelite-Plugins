package net.runelite.client.plugins.arooftops;

public enum ARooftopsObstacleType {
    NORMAL,
    DECORATION,
    GROUND_OBJECT
}
