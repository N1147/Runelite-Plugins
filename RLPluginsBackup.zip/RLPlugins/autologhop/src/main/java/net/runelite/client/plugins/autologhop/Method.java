package net.runelite.client.plugins.autologhop;

public enum Method {
    LOGOUT,
    HOP,
    LOGOUT_HOP,
    ROYAL_SEED_POD
}
