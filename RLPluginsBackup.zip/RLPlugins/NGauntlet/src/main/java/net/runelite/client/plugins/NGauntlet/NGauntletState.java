package net.runelite.client.plugins.NGauntlet;

public enum NGauntletState
{
	IDLE,
	IDLE_2,
	ANIMATING,
	TIMEOUT,
	UNHANDLED_STATE;
}
